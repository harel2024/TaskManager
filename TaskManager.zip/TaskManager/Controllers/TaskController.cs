﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManager.Data;
using TaskManager.Models;

namespace TaskManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskController : Controller
    {
     
        private readonly TaskManagerDbContex _context; // Holds the DB context
        private readonly ILogger<TaskController> _logger; // Holds logger to log stuff



        public TaskController(TaskManagerDbContex context, ILogger<TaskController> logger)
        {
            _context = context;
            _logger = logger;
        }
        //להביא את כל ההזמנות הקיימות
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetAllOrder()
        {

            return await _context.Tasks.ToListAsync(); 

        }

    }
}
